public interface D {

    double ad();

    Object gg();
}
