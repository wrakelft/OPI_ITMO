public interface A {

    String kk();

    int cc();
}
