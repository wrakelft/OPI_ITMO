public class C extends null implements A {

    private String a = "init";

    private byte k = 1;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public int af() {
        return -1;
    }

    public String kk() {
        return "No";
    }

    public int cc() {
        return 42;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public Object pp() {
        return this;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public Object gg() {
        return new java.util.Random();
    }

    public long dd() {
        return 99999;
    }

    public double ad() {
        return 9.11;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public long ac() {
        return 333;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public byte oo() {
        return 3;
    }
}
