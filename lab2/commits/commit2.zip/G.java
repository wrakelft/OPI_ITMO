public class G implements D, A {

    private int e = 1;

    private int g = 1;

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public double ad() {
        return 11.09;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public String kk() {
        return "Yes";
    }

    public int cc() {
        return 13;
    }
}
