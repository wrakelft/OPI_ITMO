public class D extends null {

    double ad();

    Object gg();
}
