public class A extends null {

    String kk();

    int cc();
}
