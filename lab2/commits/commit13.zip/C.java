public class C extends null implements A {

    private String a = "init";

    private byte k = 1;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public int af() {
        return -1;
    }

    public String kk() {
        return "No";
    }

    public int cc() {
        return 42;
    }

    public Object pp() {
        return this;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public Object gg() {
        return new java.util.Random();
    }

    public long dd() {
        return 99999;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public long ac() {
        return 333;
    }
}
