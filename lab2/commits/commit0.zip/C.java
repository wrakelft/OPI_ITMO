public class C implements A {

    private String a = "init";

    private byte k = 1;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public int af() {
        return -1;
    }

    public String kk() {
        return "No";
    }

    public int cc() {
        return 42;
    }
}
